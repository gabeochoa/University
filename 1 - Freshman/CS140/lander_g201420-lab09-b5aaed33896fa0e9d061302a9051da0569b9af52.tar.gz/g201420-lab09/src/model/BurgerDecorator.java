package model;
public abstract class BurgerDecorator extends BurgerModel {
	protected BurgerModel next;
	protected int calories;
	protected Double price;
	public BurgerModel addTopping(BurgerModel burger) {
		// assign "this.next" so that it references burger 
		return this;  
	}
	public BurgerModel removeTopping (BurgerDecorator topping) {
		BurgerModel retVal = this;
		// if "this" is the topping to be removed, assign retVal to next
		// (since the toppings are Singleton objects you can
		// use == to test for equality of objects in this case,
		// i.e. if(this == topping)
		// otherwise next = next.removeTopping (topping)
		return retVal;
	}
}
