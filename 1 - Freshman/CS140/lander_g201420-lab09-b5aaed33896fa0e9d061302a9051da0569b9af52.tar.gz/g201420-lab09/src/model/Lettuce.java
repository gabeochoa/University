package model;

import view.ToppingsManager;

public class Lettuce extends BurgerDecorator {
	private static BurgerModel singleton = new Lettuce();
	private Lettuce () {
	}
	public static BurgerModel getHandle() {
		return singleton;
	}
	public int getTotalCalories() {
		String str = getClass().getSimpleName().toLowerCase();
		return ToppingsManager.toppingsMap.get(str).getCalories() 
				+ next.getTotalCalories();
	}

	public Double getTotalPrice() {
		// this should be similar to getTotalCalories
		return new Double(0); //remove this line after completing the line above
	}

}
