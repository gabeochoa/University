package nim;
interface Play {
	int takeTurn(int currentState);
}