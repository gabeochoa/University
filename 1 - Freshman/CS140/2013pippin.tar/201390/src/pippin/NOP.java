package pippin;
public class NOP extends Instruction {
	
	public NOP(Processor cpu, Memory memory) {
		super(cpu, memory);
	}

	@Override
	public void execute(int arg, boolean immediate, boolean indirect)
			throws DataAccessException {
		if (immediate) {
			throw new IllegalInstructionModeException("attempt to execute immediate NOP");
		} else if (indirect) {
			throw new IllegalInstructionModeException("attempt to execute indirect NOP");
		} 
		cpu.incrementCounter();		
	}
}
