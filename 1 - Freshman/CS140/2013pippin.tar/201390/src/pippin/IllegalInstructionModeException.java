package pippin;

public class IllegalInstructionModeException extends RuntimeException {

	private static final long serialVersionUID = -4556966139262712625L;

	public IllegalInstructionModeException() {
	}

	public IllegalInstructionModeException(String arg0) {
		super(arg0);
	}

}
