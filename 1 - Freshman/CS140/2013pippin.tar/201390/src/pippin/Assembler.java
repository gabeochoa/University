package pippin;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;

public class Assembler {
	static Set<String> allowsImmediate = new HashSet<String>();
	static Set<String> allowsIndirect = new HashSet<String>();
	static Set<String> noArgument = new HashSet<String>();
	static Map<String, Integer> opcode = new HashMap<String, Integer>();

	static {
		allowsImmediate.add("LOD");
		allowsImmediate.add("ADD");
		allowsImmediate.add("SUB");
		allowsImmediate.add("MUL");
		allowsImmediate.add("DIV");
		allowsImmediate.add("AND");

		allowsIndirect.add("LOD");
		allowsIndirect.add("STO");
		allowsIndirect.add("JUMP");
		allowsIndirect.add("JMPZ");
		allowsIndirect.add("ADD");
		allowsIndirect.add("SUB");
		allowsIndirect.add("MUL");
		allowsIndirect.add("DIV");
		allowsIndirect.add("LOD");

		noArgument.add("HALT");
		noArgument.add("NOP");
		noArgument.add("NOT");

		opcode.put("LOD", 1);
		opcode.put("STO", 2);
		opcode.put("JUMP", 11);
		opcode.put("JMPZ", 12);
		opcode.put("NOP", 0);
		opcode.put("HALT", 15);
		opcode.put("ADD", 3);
		opcode.put("SUB", 4);
		opcode.put("MUL", 5);
		opcode.put("DIV", 6);
		opcode.put("AND", 7);
		opcode.put("NOT", 8);
		opcode.put("CMPZ", 9);
		opcode.put("CMPL", 10);
	}


	public static boolean assemble(File input, File output) {
		boolean goodProgram = false; // will be used at end of method
		try {
			goodProgram = true;
			Scanner inp = new Scanner(input);
			PrintWriter outp = new PrintWriter(output);
			boolean blankLineHit = false; //keep track of when we hit a blank line
			boolean inCode = true; //keep track that we are in the code, not in data
			int lineCounter = 0;
			while(inp.hasNextLine() && goodProgram) {
				lineCounter++;
				String line = inp.nextLine().trim();
				if (line.equals("DATA")) {
					inCode = false;
					outp.println(-1);
				} else {
					String[] parts = line.trim().split("\\s+");
					if(inCode) {
						if(parts.length == 1) {
							outp.println(4*opcode.get(parts[0]));
							outp.println(0);
						} else {
							char ch = parts[0].charAt(parts[0].length()-1);
							if(ch == '#') {
								String temp = parts[0].substring(0,parts[0].length()-1);
								outp.println(4*opcode.get(temp)+1);
								outp.println(Integer.parseInt(parts[1],16));								
							} else if(ch == '&') {
								String temp = parts[0].substring(0,parts[0].length()-1);
								outp.println(4*opcode.get(temp)+2);
								outp.println(Integer.parseInt(parts[1],16));
							} else {
								outp.println(4*opcode.get(parts[0]));
								outp.println(Integer.parseInt(parts[1],16));								
							}
						}
						
					} else {
						outp.println(Integer.parseInt(parts[0],16));
						outp.println(Integer.parseInt(parts[1],16));														
					}
				}
			}
			inp.close();
			outp.close();
		} catch (IOException e){
			System.out.println("Unable to open the necessary files");
		}
		if(!goodProgram && output != null && output.exists()) {
			output.delete();
		}
		return goodProgram;

	}

}
