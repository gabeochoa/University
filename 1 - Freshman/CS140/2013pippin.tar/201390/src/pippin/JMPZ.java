package pippin;
public class JMPZ extends Instruction {
	
	public JMPZ(Processor cpu, Memory memory) {
		super(cpu, memory);
	}

	@Override
	public void execute(int arg, boolean immediate, boolean indirect)
			throws DataAccessException {
		if (immediate) {
			throw new IllegalInstructionModeException("attempt to execute immediate JMPZ");
		} else if (indirect) {
			arg = memory.getData(arg);
		} 
		if(cpu.getAccumulator() == 0) {
			cpu.setProgramCounter(arg);
		} else {
			cpu.incrementCounter();		
		}
	}
}
