package pippin;
public class STO extends Instruction {

	public STO(Processor cpu, Memory memory) {
		super(cpu, memory);
	}

	@Override
	public void execute(int arg, boolean immediate, boolean indirect)
			throws DataAccessException {
		int address = arg;
		if (immediate) {
			throw new IllegalInstructionModeException("attempt to execute immediate STO");
		} else if (indirect) {
			address = memory.getData(arg);
		} 
		memory.setData(address, cpu.getAccumulator());
		cpu.incrementCounter();		
	}
}
