package pippin;
public class JUMP extends Instruction {
	
	public JUMP(Processor cpu, Memory memory) {
		super(cpu, memory);
	}

	@Override
	public void execute(int arg, boolean immediate, boolean indirect)
			throws DataAccessException {
		if (immediate) {
			throw new IllegalInstructionModeException("attempt to execute immediate JUMP");
		} else if (indirect) {
			arg = memory.getData(arg);
		}
		cpu.setProgramCounter(arg);
	}
}
