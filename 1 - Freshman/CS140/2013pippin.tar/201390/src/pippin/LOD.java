package pippin;
public class LOD extends Instruction {
	
	public LOD(Processor cpu, Memory memory) {
		super(cpu, memory);
	}

	@Override
	public void execute(int arg, boolean immediate, boolean indirect)
			throws DataAccessException {
		int operand = memory.getData(arg);
		if (immediate) {
			operand = arg;
		} else if (indirect) {
			operand = memory.getData(operand);
		} 
        cpu.setAccumulator(operand);
		cpu.incrementCounter();		
	}
}