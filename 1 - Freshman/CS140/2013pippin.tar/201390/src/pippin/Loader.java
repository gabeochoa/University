package pippin;

import java.io.File;

public class Loader {
	public static void load(Memory mem, File file) {
			}
}
