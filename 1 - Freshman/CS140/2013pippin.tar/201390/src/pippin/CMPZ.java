package pippin;
public class CMPZ extends Instruction {
	
	public CMPZ(Processor cpu, Memory memory) {
		super(cpu, memory);
	}

	@Override
	public void execute(int arg, boolean immediate, boolean indirect)
			throws DataAccessException {
		int operand = memory.getData(arg);
		if (immediate) {
			throw new IllegalInstructionModeException("attempt to execute indirect AND");
		} else if (indirect) {
			throw new IllegalInstructionModeException("attempt to execute indirect AND");
		} 
        if(operand == 0) {
            cpu.setAccumulator(1);        	
        } else {
            cpu.setAccumulator(0);        	
        }
        cpu.incrementCounter();
    }

}
