package pippin;

public class DIV extends Instruction {

	public DIV(Processor cpu, Memory memory) {
		super(cpu, memory);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void execute(int arg, boolean immediate, boolean indirect)
			throws DataAccessException {
		if (immediate) {
			if(arg == 0) {
				throw new DivideByZeroException("attempt to divide by zero");
			}
			cpu.setAccumulator(cpu.getAccumulator() / arg);
		} else if (indirect) {
			int arg1 = memory.getData(arg);
			if(memory.getData(arg1) == 0) {
				throw new DivideByZeroException("attempt to divide by zero");
			}
			cpu.setAccumulator(cpu.getAccumulator() / memory.getData(arg1));					
		} else {
			if(memory.getData(arg) == 0) {
				throw new DivideByZeroException("attempt to divide by zero");
			}
			cpu.setAccumulator(cpu.getAccumulator() / memory.getData(arg));			
		}
		cpu.incrementCounter();
		
	}
}
