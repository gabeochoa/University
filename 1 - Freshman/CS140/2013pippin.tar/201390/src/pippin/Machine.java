package pippin;

import java.io.File;
import java.util.Scanner;

public class Machine {
	public final Instruction[] INSTRUCTION_SET = new Instruction[16];
	private Processor proc = new Processor();
	private Memory memory = new Memory();
	private boolean running = false;

	public Machine() {
		INSTRUCTION_SET[0] = new NOP(proc, memory);
		// fill in the other elements
		INSTRUCTION_SET[15] = new HALT(proc, memory);
		((HALT)INSTRUCTION_SET[15]).setMachine(this);
	}
	
	public void halt() {
		running = false;
	}

	public boolean isRunning() {
		return running;
	}

	public void setRunning(boolean running) {
		this.running = running;
	}
	
	public static void main(String[] args) throws CodeAccessException, DataAccessException {
		Machine sim = new Machine();
		System.out.println("Name of file to assemble and run: ");
		Scanner keyboard = new Scanner(System.in);
		File asm = new File(keyboard.nextLine());
		if(asm.exists()) {
			File exe = new File("temp.pipex");
			Assembler.assemble(asm, exe);
			Loader.load(sim.memory, exe);
			sim.running = true;

			sim.proc.setProgramCounter(0);

			int pc = 0;
			
			while(sim.running) {
				pc = sim.proc.getProgramCounter();
				int opcode = sim.memory.getOpcode(pc);
				Instruction in = sim.INSTRUCTION_SET[opcode/4];	
				int arg = sim.memory.getArg(pc);
				boolean immediate = opcode % 2 == 1;
				boolean indirect = (opcode/2) % 2 == 1;
				in.execute(arg, immediate, indirect);
			}
			for(int i = 0; i < 32; i++) {
				for(int j = 0; j < 16; j++) {
					System.out.print(16*i+j + ": " + sim.memory.getData(16*i+j) + " | ");
				}
				System.out.println();
			}
		} else {
			System.out.println("Sorry, cannot find file: " + asm.getAbsolutePath());
		}
		
		
		keyboard.close();
	}

}
