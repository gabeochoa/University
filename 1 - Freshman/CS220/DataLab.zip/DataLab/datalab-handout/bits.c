/* 
 * CS:APP Data Lab 
 * 
 * Gabriel Ochoa -  gochoa1
 * 
 * bits.c - Source file with your solutions to the Lab.
 *          This is the file you will hand in to your instructor.
 *
 * WARNING: Do not include the <stdio.h> header; it confuses the dlc
 * compiler. You can still use printf for debugging without including
 * <stdio.h>, although you might get a compiler warning. In general,
 * it's not good practice to ignore compiler warnings, but in this
 * case it's OK.  
 */

#if 0
/*
 * Instructions to Students:
 *
 * STEP 1: Read the following instructions carefully.
 */

You will provide your solution to the Data Lab by
editing the collection of functions in this source file.

INTEGER CODING RULES:
 
  Replace the "return" statement in each function with one
  or more lines of C code that implements the function. Your code 
  must conform to the following style:
 
  int Funct(arg1, arg2, ...) {
      /* brief description of how your implementation works */
      int var1 = Expr1;
      ...
      int varM = ExprM;

      varJ = ExprJ;
      ...
      varN = ExprN;
      return ExprR;
  }

  Each "Expr" is an expression using ONLY the following:
  1. Integer constants 0 through 255 (0xFF), inclusive. You are
      not allowed to use big constants such as 0xffffffff.
  2. Function arguments and local variables (no global variables).
  3. Unary integer operations ! ~
  4. Binary integer operations & ^ | + << >>
    
  Some of the problems restrict the set of allowed operators even further.
  Each "Expr" may consist of multiple operators. You are not restricted to
  one operator per line.

  You are expressly forbidden to:
  1. Use any control constructs such as if, do, while, for, switch, etc.
  2. Define or use any macros.
  3. Define any additional functions in this file.
  4. Call any functions.
  5. Use any other operations, such as &&, ||, -, or ?:
  6. Use any form of casting.
  7. Use any data type other than int.  This implies that you
     cannot use arrays, structs, or unions.

 
  You may assume that your machine:
  1. Uses 2s complement, 32-bit representations of integers.
  2. Performs right shifts arithmetically.
  3. Has unpredictable behavior when shifting an integer by more
     than the word size.

EXAMPLES OF ACCEPTABLE CODING STYLE:
  /*
   * pow2plus1 - returns 2^x + 1, where 0 <= x <= 31
   */
  int pow2plus1(int x) {
     /* exploit ability of shifts to compute powers of 2 */
     return (1 << x) + 1;
  }

  /*
   * pow2plus4 - returns 2^x + 4, where 0 <= x <= 31
   */
  int pow2plus4(int x) {
     /* exploit ability of shifts to compute powers of 2 */
     int result = (1 << x);
     result += 4;
     return result;
  }

FLOATING POINT CODING RULES

For the problems that require you to implent floating-point operations,
the coding rules are less strict.  You are allowed to use looping and
conditional control.  You are allowed to use both ints and unsigneds.
You can use arbitrary integer and unsigned constants.

You are expressly forbidden to:
  1. Define or use any macros.
  2. Define any additional functions in this file.
  3. Call any functions.
  4. Use any form of casting.
  5. Use any data type other than int or unsigned.  This means that you
     cannot use arrays, structs, or unions.
  6. Use any floating point data types, operations, or constants.


NOTES:
  1. Use the dlc (data lab checker) compiler (described in the handout) to 
     check the legality of your solutions.
  2. Each function has a maximum number of operators (! ~ & ^ | + << >>)
     that you are allowed to use for your implementation of the function. 
     The max operator count is checked by dlc. Note that '=' is not 
     counted; you may use as many of these as you want without penalty.
  3. Use the btest test harness to check your functions for correctness.
  4. Use the BDD checker to formally verify your functions
  5. The maximum number of ops for each function is given in the
     header comment for each function. If there are any inconsistencies 
     between the maximum ops in the writeup and in this file, consider
     this file the authoritative source.

/*
 * STEP 2: Modify the following functions according the coding rules.
 * 
 *   IMPORTANT. TO AVOID GRADING SURPRISES:
 *   1. Use the dlc compiler to check that your solutions conform
 *      to the coding rules.
 *   2. Use the BDD checker to formally verify that your solutions produce 
 *      the correct answers.
 */


/*
	flip odd bits 

		int a = 0xAA << 8 | 0xAA; (1010)  0xAA00 0xAAAA
		int b = a<<16;  0xAAAA0000
		return x^a^b

	int getByte(x, n)
		n = 1 x = 0x12345678
			    3 2 1 0
		returns 0x56
		
		need to shift x 
		
		x = x >> (n<<3)//puts 56 in the lsb 
		x & 0xFF; //will only give the last two bits because 0x0000...00FF

*/

#endif

/* 
 * bitNor - ~(x|y) using only ~ and & 
 *   Example: bitNor(0x6, 0x5) = 0xFFFFFFF8
 *   Legal ops: ~ &
 *   Max ops: 8
 *   Rating: 1
 */
int bitNor(int x, int y) {
    
    //de morgans law   not(p | q) <=> (not p) & (not q)
    x = (~x);
    y = (~y);
    
  return x & y;
}

/* 
 * thirdBits - return word with every third bit (starting from the LSB) set to 1
 *   Legal ops: ! ~ & ^ | + << >>
 *   Max ops: 8
 *   Rating: 1
 */
int thirdBits(void) {

	//	0100 1001 0010 0100 1001 0010 0100 1001
	//   4    9     2   4    9     2    4   9

	//Create two constants because the number repeats
	//Then shift the first constant left to make space for the next one at the end
	//Or const2 with the shifted constant, to change the trailing zeroes to 0x02

	//shift again to make space for its self at the end, doubling the number
	// from 0x492 to 0x492492

	// then shift another two bytes to add another 0x49 to the end and complete the puzzle. 

	int const1 = 0x49;
	int const2 = 0x02;
	
	int h = (const1<< 4) | const2;
	int g = (h << 12) | h;
	int word = (g<< 8) | const1;

    return word;
    
    
}
/* 
 * copyLSB - set all bits of result to least significant bit of x
 *   Example: copyLSB(5) = 0xFFFFFFFF, copyLSB(6) = 0x00000000
 *   Legal ops: ! ~ & ^ | + << >>
 *   Max ops: 5
 *   Rating: 2
 */
int copyLSB(int x) {
    
    //Shifts left 31 bits to push all but the last bit out.
    //It then right shifts back 31 usuing an arithmatic shift
    //to keep the sign
    
    return (x<<31) >> 31;
}

/* 
 * replaceByte(x,n,c) - Replace byte n in x with c
 *   Bytes numbered from 0 (LSB) to 3 (MSB)
 *   Examples: replaceByte(0x12345678,1,0xab) = 0x1234ab78
 *   You can assume 0 <= n <= 3 and 0 <= c <= 255
 *   Legal ops: ! ~ & ^ | + << >>
 *   Max ops: 10
 *   Rating: 3
 */
int replaceByte(int x, int n, int c) {
    
    int bite = x >> (n << 3);
	int ret = x & 0xFF;
    //this will get the byte that we want and put it in ret
	int borc = ((bite & c));
	int sol = borc << (n<<3);
	int solar = sol | ret;	

	//printf("\n\n %x   %x  %x   %x  %x \n\n", bite, ret, borc, sol, solar);
	
  	return solar;
    
    //
}
/* 
 * logicalShift - shift x to the right by n, using a logical shift
 *   Can assume that 0 <= n <= 31
 *   Examples: logicalShift(0x87654321,4) = 0x08765432
 *   Legal ops: ~ & ^ | + << >>
 *   Max ops: 20
 *   Rating: 3 
 */
int logicalShift(int x, int n) {
    
    //Shifts negative 1, and then nots it, to get the shift on the right side
    //of the number
    
    int z = -1 << n;
    int a = ~(z);
    
    //it then shifts to the left byt (32-n) to move the 1's to the bits that were added by the arith. shift
    int m = a << (32 - n);
    
    //We then shift x by n (this arith. shifts and replicates the sign bit)
    int y = (x>>n);
    
    //we take the shifted number and all we need to do next is get rid of the
    //bits added to the front of x.
    
    //we or the bits
    int b =  ( y| m);
    
    //we not m,
    //to make notm all ones but the 'new bits' (the ones shifted in on x)
    int notm = ~m;
    
    //because notm and y(the new x) both share the original msb, that is saved and
    //all of the shifted in bits are gone.
    int solution = notm & b;
    
    return  solution;
   // return sol;
}
/* 
 * greatestBitPos - return a mask that marks the position of the
 *               most significant 1 bit. If x == 0, return 0
 *   Example: greatestBitPos(96) = 0x40
 *   Legal ops: ! ~ & ^ | + << >>
 *   Max ops: 70
 *   Rating: 4 
 */
int greatestBitPos(int x) {
    //lsb would be      negx = ~x+1   return negx & x
    
    int out = (x & 0) | (~x & 1);

    
  return 2;
}
/*
 * isTmax - returns 1 if x is the maximum, two's complement number,
 *     and 0 otherwise 
 *   Legal ops: ! ~ & ^ | +
 *   Max ops: 10
 *   Rating: 1
 */
int isTmax(int x) {
    
    //take the smallest number and flip to get the
    //largest Twos Complement number, then compare to
    //it to see if they are the same.

    int smallest = ~(1<<31);
    
	return !(x^smallest);


}
/*
 * ezThreeFourths - multiplies by 3/4 rounding toward 0,
 *   Should exactly duplicate effect of C expression (x*3/4),
 *   including overflow behavior.
 *   Examples: ezThreeFourths(11) = 8
 *             ezThreeFourths(-9) = -6
 *             ezThreeFourths(1073741824) = -268435456 (overflow)
 *   Legal ops: ! ~ & ^ | + << >>
 *   Max ops: 12
 *   Rating: 3
 */
int ezThreeFourths(int x) {
    
    //rounding error, maybe ~~x could round
    
    //result is always rounded down, meaning this only works for positive numbers
    
    /*how to handle when negative
        add one if negative
          
        from the powerpoint 
        (x + (1 << k ) -1 )>> k
    */
    int k = (x<< 1) + x;
    int sign = x>>31;
    
	    
  //  int bitsLessThanN = ~((~0)<<n); 

    /*
     
     int isn = x>>31; // to find the MSB of x
     int xp = x >> n; // divide by n
     int xn = (x + ((1<<n)+(˜0))) >> n; // 
     return (xn & isn) | (xp & (˜isn));
     
     
     /* For negative x, a bias will need
     * to be added to make sure x
     * rounds in the correct direction

    int bitsLessThanN =  ̃(( ̃0)<<n);  
    int bias = (x>>31)&bitsLessThanN;
    int answer = (x+bias)>>n;

     */
    
  return k;
}
/* 
 * isAsciiDigit - return 1 if 0x30 <= x <= 0x39 (ASCII codes for characters '0' to '9')
 *   Example: isAsciiDigit(0x35) = 1.
 *            isAsciiDigit(0x3a) = 0.
 *            isAsciiDigit(0x05) = 0.
 *   Legal ops: ! ~ & ^ | + << >>
 *   Max ops: 15
 *   Rating: 3
 */
int isAsciiDigit(int x) {
  return 2;
}
/* 
 * isGreater - if x > y  then return 1, else return 0 
 *   Example: isGreater(4,5) = 0, isGreater(5,4) = 1
 *   Legal ops: ! ~ & ^ | + << >>
 *   Max ops: 24
 *   Rating: 3
 */
int isGreater(int x, int y) {
    
    //check the signs of both params,
    // if the signs are the same then    
    //add x to neg y and if pos then greater, otherwise less than
    
    //if the signs dont match, then find the positive one, it is larger
    
    return 2;
}
/* 
 * isNonZero - Check whether x is nonzero using
 *              the legal operators except !
 *   Examples: isNonZero(3) = 1, isNonZero(0) = 0
 *   Legal ops: ~ & ^ | + << >>
 *   Max ops: 10
 *   Rating: 4 
 */
int isNonZero(int x) {
    
    /*
     
     For example: 0x1234
     
     x = 0001 0010 0011 0100          x = 0001 0010 0011 0100
     
                                   + ~0 = 1111 1111 1111 1111
     
     ~x = 1110 1101 1100 1011       &     0001 0001 0111 0011
     
     a  = 0000 0001 0100 0011
     ~a = 1111 1110 1011 1100
     
     b  = 0000 0000 0000 0001
     
     
     
     For example: 0x0
     
     x = 0000 0000 0000 0000          x = 0000 0000 0000 0000
     
                                   + ~0 = 1111 1111 1111 1111
     
     ~x = 1111 1111 1111 1111       &     1111 1111 1111 1111
     
     
     a  = 1111 1111 1111 1111
     ~a = 0000 0000 0000 0000
     
     b  = 0000 0000 0000 0000
     
     */
    
    
    int a = (~x) & (x + ~0);
    int b = (~a >> 31);
    
    return b & 1;
}

/* 
 * sm2tc - Convert from sign-magnitude to two's complement
 *   where the MSB is the sign bit
 *   Example: sm2tc(0x80000005) = -5.
 *   Legal ops: ! ~ & ^ | + << >>
 *   Max ops: 15
 *   Rating: 4
 */

int sm2tc(int x) {
    //get the sign of the value
    // if the sign is zero, nothing has to be done
    
    //if not then add one.
    
    int sign  =   x>>31;
    int OneBit = 1 << 31;

    
    return x;
}

/*
 * float_abs - Return bit-level equivalent of absolute value of f for
 *   floating point argument f.
 *   Both the argument and result are passed as unsigned int's, but
 *   they are to be interpreted as the bit-level representations of
 *   single-precision floating point values.
 *   When argument is NaN, return argument..
 *   Legal ops: Any integer/unsigned operations incl. ||, &&. also if, while
 *   Max ops: 10
 *   Rating: 2
 */
unsigned float_abs(unsigned uf) {
    
  return (uf << 1) >> 1;
}
/* 
 * float_half - Return bit-level equivalent of expression 0.5*f for
 *   floating point argument f.
 *   Both the argument and result are passed as unsigned int's, but
 *   they are to be interpreted as the bit-level representation of
 *   single-precision floating point values.
 *   When argument is NaN, return argument
 *   Legal ops: Any integer/unsigned operations incl. ||, &&. also if, while
 *   Max ops: 30
 *   Rating: 4
 */
unsigned float_half(unsigned uf) {

            return uf>>1;
}
/* 
 * float_i2f - Return bit-level equivalent of expression (float) x
 *   Result is returned as unsigned int, but
 *   it is to be interpreted as the bit-level representation of a
 *   single-precision floating point values.
 *   Legal ops: Any integer/unsigned operations incl. ||, &&. also if, while
 *   Max ops: 30
 *   Rating: 4
 */
unsigned float_i2f(int x) {
    unsigned sign = uf >> 31;
    unsigned exponent = (uf >> 23) & 0xFF;
    unsigned mantissa = uf & 0x7FFFFF;
    
    
  return 2;
}
