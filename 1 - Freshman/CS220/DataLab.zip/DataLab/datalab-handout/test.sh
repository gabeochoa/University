make clean\
make btest\
./btest -g